package ext;

import dao.IDao;

public class DaoImplV2 implements IDao {

    @Override
    public double getData() {
        System.out.println("version captures");
        double temperature=80;
        return temperature;
    }
}
