package ext;

import dao.IDao;

public class DaoImpLVWS implements IDao {
    @Override
    public double getData() {
        System.out.println("Version Web service");
        return 90;
    }
}
