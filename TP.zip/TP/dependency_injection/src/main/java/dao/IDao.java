package dao;

public interface IDao {
      double getData();


}
