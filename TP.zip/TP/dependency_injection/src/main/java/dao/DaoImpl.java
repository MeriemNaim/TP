package dao;

public class DaoImpl implements IDao {

    @Override
    public double getData() {
        System.out.println("Version Base de Donnees");
 double temperature=Math.random()*40;
        return temperature;
    }
}

